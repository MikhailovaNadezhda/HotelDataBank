USE [HotelProjekt];
GO
SELECT dbo.sf_MonatlichesEinkommen(4) AS 'Monatliches Einkommen';