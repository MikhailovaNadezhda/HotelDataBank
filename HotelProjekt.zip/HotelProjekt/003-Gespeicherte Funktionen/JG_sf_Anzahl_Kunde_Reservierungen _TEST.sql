USE [Hotelprojekt]
GO

SELECT dbo.sf_Anzahl_Kunde_Reservierungen(7) AS 'Anzahl_Reservierungen';