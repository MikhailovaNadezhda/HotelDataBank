SELECT [dbo].[Sf_Anzahl_Reserv_Kunde](4)
