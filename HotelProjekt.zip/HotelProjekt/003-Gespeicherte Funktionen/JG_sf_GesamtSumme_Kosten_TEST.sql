USE [Hotelprojekt]
GO

SELECT dbo.sf_GesamtSumme(7) AS 'GesamtSumme';