select [dbo].[sf_Count_Frei_Zimmer_Date]('18.04.2023') 
