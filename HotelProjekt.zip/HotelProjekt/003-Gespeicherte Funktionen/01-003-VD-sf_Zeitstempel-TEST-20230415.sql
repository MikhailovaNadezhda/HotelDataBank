USE Hotelprojekt
GO

PRINT [dbo].[sf_Zeitstempel]();