USE [HotelProjekt];
GO
SELECT * FROM [dbo].[tf_UngereinigteZimmer](GETDATE())