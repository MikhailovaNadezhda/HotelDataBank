USE [Hotelprojekt]
GO

DECLARE @Zimmer smallint = 101
DECLARE @Datum date = '10.05.2023'
--DECLARE @Datum date = '25.04.2023' - etledigt nicht


SELECT * FROM tf_WerPersonal_Datum_Zimmer_Reiniegung(@Zimmer, @Datum)