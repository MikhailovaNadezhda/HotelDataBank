USE [HotelProjekt];
GO
SELECT * FROM [dbo].[tf_PersonalFreiDatum]('28.04.2023',1,3)